<?php
/**
 * 課金グループ削除要求レスポンスDTO
 * @author Veritrans, Inc.
 */
class ChargeDeleteResponseDto extends AbstractPayNowIdResponseDto {

}

?>
