<?php
class MdkBaseDto { }
?>
