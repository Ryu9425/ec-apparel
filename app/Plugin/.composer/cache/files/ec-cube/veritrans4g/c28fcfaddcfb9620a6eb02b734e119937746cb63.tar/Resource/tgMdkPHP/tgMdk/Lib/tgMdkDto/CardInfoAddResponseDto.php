<?php
/**
 * カード情報追加要求レスポンスDTO
 * @author Veritrans, Inc.
 */
class CardInfoAddResponseDto extends AbstractPayNowIdResponseDto {

}

?>
