<?php
/**
 * 会員情報追加要求レスポンスDTO
 * @author Veritrans, Inc.
 */
class AccountAddResponseDto extends AbstractPayNowIdResponseDto {

}

?>
