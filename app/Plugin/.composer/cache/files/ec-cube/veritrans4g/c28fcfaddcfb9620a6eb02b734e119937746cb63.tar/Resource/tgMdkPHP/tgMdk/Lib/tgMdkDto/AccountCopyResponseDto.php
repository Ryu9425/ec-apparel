<?php
/**
 * 会員情報複製要求レスポンスDTO
 * @author Veritrans, Inc.
 */
class AccountCopyResponseDto extends AbstractPayNowIdResponseDto {

}

?>
