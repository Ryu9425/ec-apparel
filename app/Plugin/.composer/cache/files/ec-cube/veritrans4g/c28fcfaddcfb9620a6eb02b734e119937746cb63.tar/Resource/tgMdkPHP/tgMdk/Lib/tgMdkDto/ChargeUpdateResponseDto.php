<?php
/**
 * 課金グループ変更要求レスポンスDTO
 * @author Veritrans, Inc.
 */
class ChargeUpdateResponseDto extends AbstractPayNowIdResponseDto {

}

?>
