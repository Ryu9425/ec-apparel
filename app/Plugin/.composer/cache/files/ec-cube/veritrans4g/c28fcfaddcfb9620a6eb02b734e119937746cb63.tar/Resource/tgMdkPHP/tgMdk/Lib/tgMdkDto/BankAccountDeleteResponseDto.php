<?php
/**
 * 銀行口座情報削除レスポンスDTO
 * @author Veritrans, Inc.
 */
class BankAccountDeleteResponseDto extends AbstractPayNowIdResponseDto {

}

?>
