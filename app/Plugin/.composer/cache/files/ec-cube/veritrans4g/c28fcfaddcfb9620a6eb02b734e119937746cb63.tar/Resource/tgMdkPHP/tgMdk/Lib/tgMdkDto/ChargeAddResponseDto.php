<?php
/**
 * 課金グループ情報追加要求レスポンスDTO
 * @author Veritrans, Inc.
 */
class ChargeAddResponseDto extends AbstractPayNowIdResponseDto {

}

?>
