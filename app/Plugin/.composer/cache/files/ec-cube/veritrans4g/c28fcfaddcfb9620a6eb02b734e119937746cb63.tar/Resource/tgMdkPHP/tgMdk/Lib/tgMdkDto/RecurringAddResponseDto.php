<?php
/**
 * 継続課金情報追加要求レスポンスDTO
 * @author Veritrans, Inc.
 */
class RecurringAddResponseDto extends AbstractPayNowIdResponseDto{

}

?>
