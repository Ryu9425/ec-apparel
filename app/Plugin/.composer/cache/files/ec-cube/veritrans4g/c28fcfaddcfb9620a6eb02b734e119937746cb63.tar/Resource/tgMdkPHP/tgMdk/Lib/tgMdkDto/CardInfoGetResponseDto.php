<?php
/**
 * カード情報取得要求レスポンスDTO
 * @author Veritrans, Inc.
 */
class CardInfoGetResponseDto extends AbstractPayNowIdResponseDto {

}

?>
