<?php
/**
 * 会員情報復元要求レスポンスDTO
 * @author Veritrans, Inc.
 */
class AccountRestoreResponseDto extends AbstractPayNowIdResponseDto {

}

?>
