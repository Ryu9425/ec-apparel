<?php
/**
 * Created by SYSTEM_KD
 * Date: 2019-10-24
 */
return [
    'under_quantity.admin.quantity_label' => '最低購入数',
    'under_quantity.admin.quantity_help' => '購入者が購入する際の最低個数を制限することができます。',
    'under_quantity.front.shopping.under_limit_zero' =>  '「%product%」は販売制限しております。最低購入数を下回る数量での購入はできません。',
    'under_quantity.front.shopping.under_limit' =>  '「%product%」は販売制限しております。最低購入数を下回る数量のため数量を調整しました。',
];
