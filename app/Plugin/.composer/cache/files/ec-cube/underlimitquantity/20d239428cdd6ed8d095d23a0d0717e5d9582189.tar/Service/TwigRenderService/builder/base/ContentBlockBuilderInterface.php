<?php
/**
 * Copyright(c) 2019 SYSTEM_KD
 * Date: 2019/03/21
 */

namespace Plugin\UnderLimitQuantity\Service\TwigRenderService\builder\base;


/**
 * Interface ContentBlockBuilderInterface
 */
interface ContentBlockBuilderInterface
{
    public function build();
}
