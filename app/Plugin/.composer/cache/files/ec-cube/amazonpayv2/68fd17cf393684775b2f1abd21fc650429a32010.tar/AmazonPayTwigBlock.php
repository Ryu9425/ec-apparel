<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.3   |
    |              on 2021-07-20 10:45:27              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
namespace Plugin\AmazonPayV2;use Eccube\Common\EccubeTwigBlock;class AmazonPayTwigBlock implements EccubeTwigBlock{public static function getTwigBlock(){return [];}}