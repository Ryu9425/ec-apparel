<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.3   |
    |              on 2021-07-20 10:45:27              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
namespace Plugin\AmazonPayV2;use Eccube\Common\EccubeNav;class AmazonPayNav implements EccubeNav{public static function getNav(){return ['order' => ['children' => ['amazon_pay_v2_admin_payment_status' => ['name' => 'amazon_pay_v2.admin.nav.payment_list', 'url' => 'amazon_pay_v2_admin_payment_status']]]];}}