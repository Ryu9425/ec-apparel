<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.3   |
    |              on 2021-07-20 10:45:27              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
namespace Plugin\AmazonPayV2\Form\Type\Master;class ConfigTypeMaster{const ACCOUNT_MODE = array('SHARED' => 1, 'OWNED' => 2);const ENV = array('SANDBOX' => 1, 'PROD' => 2);const SALE = array('AUTORI' => 1, 'CAPTURE' => 2);const CART_BUTTON_PLACE = array('AUTO' => 1, 'MANUAL' => 2);const MYPAGE_LOGIN_BUTTON_PLACE = array('AUTO' => 1, 'MANUAL' => 2);const PRODUCTS_BUTTON_PLACE = array('AUTO' => 1, 'MANUAL' => 2);}